<?php
/*
Plugin Name: WooCommerce & eBay Commission Calculator
Description: Automates commission calculations for WooCommerce and eBay orders.
Version: 1.1
Author: S.A. Self Defense
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly

}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'admin-settings-page.php';
require_once plugin_dir_path(__FILE__) . 'sales-overview-page.php';

// Register activation hook
register_activation_hook(__FILE__, 'wecc_activate_plugin');
function wecc_activate_plugin() {
    // Add default commission percentage if not set
    if (!get_option('wecc_commission_percentage')) {
        update_option('wecc_commission_percentage', 10); // Default to 10%
    }
}

// Add admin menu
add_action('admin_menu', 'wecc_add_admin_menu');
function wecc_add_admin_menu() {
    add_menu_page(
        'Commission Calculator', // Page title
        'Commission Calculator', // Menu title
        'manage_options',       // Capability
        'wecc-commission-calculator', // Menu slug
        'wecc_sales_overview_page', // Callback function
        'dashicons-calculator', // Icon
        56 // Position
    );

    add_submenu_page(
        'wecc-commission-calculator', // Parent slug
        'Settings', // Page title
        'Settings', // Menu title
        'manage_options', // Capability
        'wecc-settings', // Menu slug
        'wecc_admin_settings_page' // Callback function
    );
}

// Enqueue admin styles
add_action('admin_enqueue_scripts', 'wecc_enqueue_admin_styles');
function wecc_enqueue_admin_styles() {
    wp_enqueue_style('wecc-admin-styles', plugins_url('assets/css/style.css', __FILE__));
}