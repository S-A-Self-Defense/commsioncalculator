<?php
/*
Plugin Name: WooCommerce & eBay Commission Calculator
Description: Automates commission calculations for WooCommerce and eBay orders.
Version: 1.1
Author: S.A. Self Defense
*/

function wecc_sales_overview_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Initialize totals
    $total_commissionable = 0;
    $total_commission = 0;

    // Fetch ONLY completed orders
    $orders = wc_get_orders(array(
        'status' => 'completed', // Only show completed orders
        'limit' => -1,
    ));

    // Handle "Calculate Selected" action
    if (isset($_POST['calculate_selected'])) {
        if (!empty($_POST['order_ids'])) {
            foreach ($_POST['order_ids'] as $order_id) {
                $order = wc_get_order($order_id);
                if (!$order) continue;

                // Calculate values
                $total = (float) $order->get_total();
                $shipping = (float) $order->get_shipping_total();
                $tax = (float) $order->get_total_tax();
                $fixed_fee = ($total * 0.0349) + 0.49;
                $commissionable_amount = $total - $shipping - $tax - $fixed_fee;
                $commission_percentage = (float) get_option('wecc_commission_percentage', 10);
                $commission = ($commissionable_amount * $commission_percentage) / 100;

                // Save to order meta
                $order->update_meta_data('_wecc_commissionable_amount', $commissionable_amount);
                $order->update_meta_data('_wecc_commission', $commission);
                $order->save();

                // Accumulate totals
                $total_commissionable += $commissionable_amount;
                $total_commission += $commission;
            }
            echo '<div class="notice notice-success"><p>Commissions calculated for selected orders!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>No orders selected!</p></div>';
        }
    }

    // Handle "Save Commission Data" action
    if (isset($_POST['save_commission_data'])) {
        if (isset($_POST['commission_paid']) && is_array($_POST['commission_paid'])) {
            foreach ($_POST['commission_paid'] as $order_id => $commission_status) {
                $order = wc_get_order($order_id);
                if (!$order) continue;

                // Sanitize input
                $commission_paid = sanitize_text_field($commission_status);
                
                // Update commission paid status
                $order->update_meta_data('_wecc_commission_paid', $commission_paid);
                
                // Handle date
                if ($commission_paid === 'yes') {
                    if (!$order->get_meta('_wecc_commission_paid_date')) {
                        $order->update_meta_data('_wecc_commission_paid_date', current_time('mysql'));
                    }
                } else {
                    $order->delete_meta_data('_wecc_commission_paid_date');
                }
                $order->save();
            }
            echo '<div class="notice notice-success"><p>Commission statuses updated!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>No changes detected!</p></div>';
        }
    }

    ?>
    <div class="wrap">
        <h1>Sales Overview</h1>
        <form method="post" action="">
            <!-- Top Buttons & Totals -->
            <div style="margin-bottom: 20px;">
                <?php
                submit_button('Calculate Selected', 'primary', 'calculate_selected');
                submit_button('Save Commission Data', 'secondary', 'save_commission_data');
                ?>
                <?php if (isset($_POST['calculate_selected'])) : ?>
                    <div class="totals-summary">
                        <h3>Totals for Selected Orders</h3>
                        <p><strong>Total Commissionable Amount:</strong> <?php echo wc_price($total_commissionable); ?></p>
                        <p><strong>Total Commission:</strong> <?php echo wc_price($total_commission); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Orders Table -->
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Order ID</th>
                        <th>Order Total</th>
                        <th>Commissionable Amount</th>
                        <th>Commission</th>
                        <th>Product Thumbnail</th>
                        <th>Commission Paid</th>
                        <th>Date Commission Paid</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) : ?>
                        <?php
                        $order_id = $order->get_id();
                        
                        // ALWAYS calculate live values
                        $total = (float) $order->get_total();
                        $shipping = (float) $order->get_shipping_total();
                        $tax = (float) $order->get_total_tax();
                        $fixed_fee = ($total * 0.0349) + 0.49;
                        $commissionable_amount = $total - $shipping - $tax - $fixed_fee;
                        $commission_percentage = (float) get_option('wecc_commission_percentage', 10);
                        $commission = ($commissionable_amount * $commission_percentage) / 100;

                        // Product thumbnail
                        $product_thumbnail = '';
                        $items = $order->get_items();
                        if (!empty($items)) {
                            $first_item = reset($items);
                            $product = $first_item->get_product();
                            if ($product) {
                                $product_thumbnail = wp_get_attachment_image_url($product->get_image_id(), 'thumbnail');
                            }
                        }

                        // Commission status
                        $commission_paid = $order->get_meta('_wecc_commission_paid', true);
                        $date_paid = $order->get_meta('_wecc_commission_paid_date', true);
                        ?>
                        <tr>
                            <td><input type="checkbox" name="order_ids[]" value="<?php echo esc_attr($order_id); ?>"></td>
                            <td>
                                <a href="<?php echo admin_url('post.php?post=' . $order_id . '&action=edit'); ?>" target="_blank">
                                    <?php echo esc_html($order_id); ?>
                                </a>
                            </td>
                            <td><?php echo wc_price($total); ?></td>
                            <td><?php echo wc_price($commissionable_amount); ?></td>
                            <td><?php echo wc_price($commission); ?></td>
                            <td>
                                <?php if ($product_thumbnail) : ?>
                                    <img src="<?php echo esc_url($product_thumbnail); ?>" width="50" height="50">
                                <?php else : ?>
                                    <span>—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select name="commission_paid[<?php echo esc_attr($order_id); ?>]">
                                    <option value="no" <?php selected($commission_paid, 'no'); ?>>No</option>
                                    <option value="yes" <?php selected($commission_paid, 'yes'); ?>>Yes</option>
                                </select>
                            </td>
                            <td>
                                <?php if ($date_paid) : ?>
                                    <?php echo esc_html(date_i18n('F j, Y', strtotime($date_paid))); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Bottom Buttons -->
            <div style="margin-top: 20px;">
                <?php
                submit_button('Calculate Selected', 'primary', 'calculate_selected');
                submit_button('Save Commission Data', 'secondary', 'save_commission_data');
                ?>
            </div>
        </form>
    </div>
    <?php
}