<?php
// admin-settings-page.php

function wecc_admin_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Save settings if form is submitted
    if (isset($_POST['wecc_save_settings'])) {
        $commission_percentage = sanitize_text_field($_POST['commission_percentage']);
        update_option('wecc_commission_percentage', $commission_percentage);
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }

    $commission_percentage = get_option('wecc_commission_percentage', 10);
    ?>
    <div class="wrap">
        <h1>Commission Calculator Settings</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="commission_percentage">Commission Percentage</label></th>
                    <td>
                        <input type="number" name="commission_percentage" id="commission_percentage" value="<?php echo esc_attr($commission_percentage); ?>" min="0" max="100" step="0.1" required> %
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings', 'primary', 'wecc_save_settings'); ?>
        </form>
    </div>
    <?php
}